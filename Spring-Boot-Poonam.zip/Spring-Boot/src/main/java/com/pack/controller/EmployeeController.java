

package com.pack.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.pack.model.Employee;
import com.pack.service.EmployeeService;

@RestController
public class EmployeeController 
{

	private EmployeeService employeeSerivce;
	 
	@Autowired
	public EmployeeController(EmployeeService employeeSerivce) {
		// TODO Auto-generated constructor stub
		this.employeeSerivce=employeeSerivce;
	}
	
	@RequestMapping(value="/addNewEmployee.html",method=RequestMethod.POST)
	public String newEmployee(Employee employee)
	{
		employeeSerivce.saveEmployee(employee);
	return("redirect/list.html");
	}
	@RequestMapping(value="/addNewEmployee.html",method=RequestMethod.GET)
	public ModelAndView addnewEmployee()
	{
		Employee employee=new Employee();
	
	return new ModelAndView("newEmployee","form",employee);
	}
	/*@RequestMapping(value="/listEmployees.html",method=RequestMethod.GET)
	public ModelAndView employees()
	{
		//List<Employee> employee=employeeRepository.findAll();
	
	return new ModelAndView("allEmployees","employess",employee);
	}*/

}

package com.pack.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.model.Employee;
import com.pack.repository.EmployeeRepository;

@Service
public class EmployeeService {

	EmployeeRepository employeeRepository ;
	
	@Autowired
	public EmployeeService(EmployeeRepository employeeRepository) {
		// TODO Auto-generated constructor stub
		this.employeeRepository=employeeRepository;
	}
	
	public void saveEmployee(Employee employee) {
		employeeRepository.save(employee);
	}
}
